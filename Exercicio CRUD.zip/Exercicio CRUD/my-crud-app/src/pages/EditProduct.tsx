import ProductForm from '../components/ProductForm';

function EditProduct() {
 return (
    <div>
        <h1>Edit Product</h1>
        <ProductForm />
    </div>
 );
}

export default EditProduct;

